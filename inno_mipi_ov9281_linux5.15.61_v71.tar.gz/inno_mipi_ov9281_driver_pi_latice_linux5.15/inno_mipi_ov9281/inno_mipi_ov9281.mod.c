#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x826b8746, "module_layout" },
	{ 0x344281e4, "param_ops_int" },
	{ 0xd6340db8, "i2c_del_driver" },
	{ 0x8953d841, "i2c_register_driver" },
	{ 0xd698e223, "v4l2_async_register_subdev" },
	{ 0xbb11e6c9, "media_entity_pads_init" },
	{ 0x1a5a8cc2, "v4l2_ctrl_handler_setup" },
	{ 0x4276b6cc, "_dev_err" },
	{ 0x85a48f1c, "v4l2_ctrl_new_int_menu" },
	{ 0xd2b3ec96, "v4l2_ctrl_new_std" },
	{ 0x96e3dd00, "v4l2_ctrl_handler_init_class" },
	{ 0x6713a251, "v4l2_i2c_subdev_init" },
	{ 0x89cfaf66, "i2c_new_dummy_device" },
	{ 0xa2a94fac, "devm_kmalloc" },
	{ 0x815588a6, "clk_enable" },
	{ 0xb077e70a, "clk_unprepare" },
	{ 0xb6e6d99d, "clk_disable" },
	{ 0x7c9a7371, "clk_prepare" },
	{ 0xe76bd549, "_dev_info" },
	{ 0xabde39d3, "_dev_warn" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0x18ecdd4c, "i2c_transfer" },
	{ 0xbf014bc1, "__v4l2_ctrl_modify_range" },
	{ 0xf0e5346c, "v4l2_ctrl_handler_free" },
	{ 0x10f27648, "v4l2_async_unregister_subdev" },
	{ 0xa05f770b, "i2c_unregister_device" },
	{ 0x73e20c1c, "strlcpy" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
};

MODULE_INFO(depends, "v4l2-async,mc,videodev");

MODULE_ALIAS("of:N*T*Comnivision,inno_mipi_ov9281");
MODULE_ALIAS("of:N*T*Comnivision,inno_mipi_ov9281C*");
MODULE_ALIAS("i2c:inno_mipi_ov9281");

MODULE_INFO(srcversion, "985139CD214760A26CBE1E6");
